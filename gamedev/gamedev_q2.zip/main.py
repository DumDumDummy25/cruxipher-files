import pyglet
from math import pi as Pi

WindowSize = [1200,700]
w = pyglet.window.Window(*WindowSize,resizable=True)
w.set_minimum_size(*WindowSize)
w.set_caption("Cruxipher")

class Pacman:
    x = 0
    y = 0
    dx = 250
    dy = 250
    left_facing = 0
    biting_freq = 0.2
    biting = 0
    colour = [(255,255,255),(204,255,51)]
    def __init__(self,x,y,biting_freq) -> None:
        self.x = x
        self.y = y
        self.batch = pyglet.graphics.Batch()
        self.biting_freq = biting_freq
        pyglet.clock.schedule_interval(self.bite,self.biting_freq)
    def bite(self,dt):
        self.biting = 1-self.biting
    def draw(self,ww,wh):
        face = pyglet.shapes.Sector(x=((ww-WindowSize[0])/2)+self.x,y=((wh-WindowSize[1])/2)+self.y,radius=20,segments=None,angle=7*Pi/4+(self.biting*Pi/6),start_angle=Pi/8+(self.left_facing*Pi)-(self.biting*Pi/12),color=self.colour[self.biting],batch=self.batch)
        eye = pyglet.shapes.Circle(x=((ww-WindowSize[0])/2)+self.x,y=((wh-WindowSize[1])/2)+self.y+10,radius=3,segments=None,color=(0,0,0),batch=self.batch)
        self.batch.draw()
    def move_up(self,dt):
        if not cc(self.x,self.y+self.dy*dt):
            self.y+=self.dy*dt
    def move_left(self,dt):
        if not cc(self.x-self.dx*dt,self.y):
            self.x-=self.dx*dt
        self.left_facing = 1
    def move_down(self,dt):
        if not cc(self.x,self.y-self.dy*dt):
            self.y-=self.dy*dt
    def move_right(self,dt):
        if not cc(self.x+self.dx*dt,self.y):
            self.x+=self.dx*dt
        self.left_facing = 0

from res import *

p = Pacman(80,80,0.2)

@w.event 
def on_draw():
    w.clear()
    wa.draw(w.width,w.height)
    if not wa.kp:
        p.draw(w.width,w.height) 

@w.event
def on_key_press(symbol,modifiers):
    if (symbol==pyglet.window.key.UP) or (symbol==pyglet.window.key.W):
        pyglet.clock.schedule_interval(p.move_up,1/120.0)
    elif (symbol==pyglet.window.key.LEFT) or (symbol==pyglet.window.key.A):
        pyglet.clock.schedule_interval(p.move_left,1/120.0)
    elif (symbol==pyglet.window.key.DOWN) or (symbol==pyglet.window.key.S):
        pyglet.clock.schedule_interval(p.move_down,1/120.0)
    elif (symbol==pyglet.window.key.RIGHT) or (symbol==pyglet.window.key.D):
        pyglet.clock.schedule_interval(p.move_right,1/120.0)

@w.event
def on_key_release(symbol,modifiers):
    if (symbol==pyglet.window.key.UP) or (symbol==pyglet.window.key.W):
        pyglet.clock.unschedule(p.move_up)
    elif (symbol==pyglet.window.key.LEFT) or (symbol==pyglet.window.key.A):
        pyglet.clock.unschedule(p.move_left)
    elif (symbol==pyglet.window.key.DOWN) or (symbol==pyglet.window.key.S):
        pyglet.clock.unschedule(p.move_down)
    elif (symbol==pyglet.window.key.RIGHT) or (symbol==pyglet.window.key.D):
        pyglet.clock.unschedule(p.move_right)

pyglet.app.run()
