#!/bin/bash

source pygpen/bin/activate
python3 main.py