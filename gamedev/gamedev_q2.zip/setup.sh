#!/bin/bash

python3 -m venv pygpen
source pygpen/bin/activate
python3 -m pip install pyglet