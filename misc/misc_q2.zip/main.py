import pyglet
from res import *
a = [5.0]

minsize = [1200,700]
s = pyglet.window.Window(*minsize,resizable=True)
s.set_minimum_size(*minsize)
s.set_caption("Cruxipher")

def placetimer(T,ww,wh):
    l = pyglet.text.Label(text="Time Left: %d s"%(T[0]),font_size=20,x=((ww-minsize[0])/2)+600,y=((wh-minsize[1])/2)+650,anchor_x='center',anchor_y='center')
    l.draw()

def dec(dt):
    a[0]-=dt

pyglet.clock.schedule_interval(dec,0.1)

class Player:
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.dx = 200
        self.dy = 200
        b.c(self.x,self.y)
        self.batch = pyglet.graphics.Batch()
    def draw(self,ww,wh):
        face = pyglet.shapes.Circle(((ww-minsize[0])/2)+self.x,((wh-minsize[1])/2)+self.y,20,color=(0,0,255),batch=self.batch)
        self.batch.draw()
    def move_up(self,dt):
        self.y += self.dy*dt
        b.c(self.x,self.y)
    def move_left(self,dt):
        self.x -= self.dx*dt
        b.c(self.x,self.y)
    def move_down(self,dt):
        self.y -= self.dy*dt
        b.c(self.x,self.y)
    def move_right(self,dt):
        self.x += self.dx*dt
        b.c(self.x,self.y)

p = Player(50,50)

@s.event
def on_draw():
    if (a[0]>0 or b.ended):
        s.clear()
    b.draw(a,s.width,s.height)
    if a[0]>0:
        placetimer(a,s.width,s.height)
        p.draw(s.width,s.height)

@s.event
def on_key_press(symbol,modifiers):
    if (symbol==pyglet.window.key.UP) or (symbol==pyglet.window.key.W):
        pyglet.clock.schedule_interval(p.move_up,1/120.0)
    elif (symbol==pyglet.window.key.LEFT) or (symbol==pyglet.window.key.A):
        pyglet.clock.schedule_interval(p.move_left,1/120.0)
    elif (symbol==pyglet.window.key.DOWN) or (symbol==pyglet.window.key.S):
        pyglet.clock.schedule_interval(p.move_down,1/120.0)
    elif (symbol==pyglet.window.key.RIGHT) or (symbol==pyglet.window.key.D):
        pyglet.clock.schedule_interval(p.move_right,1/120.0)

@s.event
def on_key_release(symbol,modifiers):
    if (symbol==pyglet.window.key.UP) or (symbol==pyglet.window.key.W):
        pyglet.clock.unschedule(p.move_up)
    elif (symbol==pyglet.window.key.LEFT) or (symbol==pyglet.window.key.A):
        pyglet.clock.unschedule(p.move_left)
    elif (symbol==pyglet.window.key.DOWN) or (symbol==pyglet.window.key.S):
        pyglet.clock.unschedule(p.move_down)
    elif (symbol==pyglet.window.key.RIGHT) or (symbol==pyglet.window.key.D):
        pyglet.clock.unschedule(p.move_right)

pyglet.app.run()
