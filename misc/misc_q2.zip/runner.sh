#!/bin/bash

source pyqpen/bin/activate
python3 main.py