#!/bin/bash

python3 -m venv pyqpen
source pyqpen/bin/activate
python3 -m pip install pyglet
python3 -m pip install qrcode[pil]