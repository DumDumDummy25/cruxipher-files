from transformers import pipeline


def find_characters(q):
    return []
