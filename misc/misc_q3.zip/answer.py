def find_characters(q):
    return []
